// Background Service Worker - Security Proxy
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === "TRANSFORM_PROMPT") {
        handleTransformation(request.data)
            .then(sendResponse)
            .catch(err => sendResponse({ error: err.message }));
        return true; // Keep message channel open for async response
    }
});

async function handleTransformation({ text, mode }) {
    const { pp_token, pp_base_url } = await chrome.storage.local.get(["pp_token", "pp_base_url"]);
    const BASE_PATH = pp_base_url || "http://localhost:3000";

    if (!pp_token) throw new Error("Sign In Required");

    const res = await fetch(`${BASE_PATH}/api/transform`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${pp_token}`
        },
        body: JSON.stringify({ text, mode })
    });

    if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || "Transformation failed");
    }

    return await res.json();
}
