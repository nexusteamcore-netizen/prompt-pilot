// content.js - Premium UI & Drag-and-Drop handling
function isContextValid() {
    try { return !!chrome.runtime?.id; } catch (e) { return false; }
}

let lastFocusedInput = null;
let ppBtn = null;
let isDragging = false;
let startX, startY, startLeft, startTop;

// Select inputs to watch for focus
const inputSelectors = [
    'div[contenteditable="true"]',
    'textarea',
    '#prompt-textarea',
    '.ProseMirror',
    'input[type="text"]'
];

function createFloatingButton() {
    if (ppBtn) return;

    ppBtn = document.createElement("button");
    ppBtn.className = "pp-enhance-btn";
    ppBtn.innerHTML = `
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1-1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
    </svg>
    <span>Enhance</span>
  `;

    // Restore position or set default
    chrome.storage.local.get(["pp_btn_pos"], (res) => {
        const pos = res.pp_btn_pos || { bottom: 20, right: 20 };
        Object.assign(ppBtn.style, {
            position: "fixed",
            bottom: pos.bottom + "px",
            right: pos.right + "px",
            left: pos.left ? pos.left + "px" : "auto",
            top: pos.top ? pos.top + "px" : "auto",
            zIndex: "2147483647",
        });
    });

    document.body.appendChild(ppBtn);

    // Drag-and-Drop Implementation
    ppBtn.addEventListener("mousedown", (e) => {
        if (e.target.closest('span') || e.target.closest('svg')) {
            // Actually maybe don't start dragging if they just click the button?
            // No, for a small button, any mousedown should allow dragging if they hold it.
        }

        isDragging = false;
        startX = e.clientX;
        startY = e.clientY;

        const rect = ppBtn.getBoundingClientRect();
        startLeft = rect.left;
        startTop = rect.top;

        const onMouseMove = (moveEvent) => {
            const dx = moveEvent.clientX - startX;
            const dy = moveEvent.clientY - startY;

            if (!isDragging && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) {
                isDragging = true;
            }

            if (isDragging) {
                ppBtn.style.left = startLeft + dx + "px";
                ppBtn.style.top = startTop + dy + "px";
                ppBtn.style.right = "auto";
                ppBtn.style.bottom = "auto";
            }
        };

        const onMouseUp = () => {
            document.removeEventListener("mousemove", onMouseMove);
            document.removeEventListener("mouseup", onMouseUp);

            if (isDragging) {
                // Save the new position
                const rect = ppBtn.getBoundingClientRect();
                chrome.storage.local.set({
                    pp_btn_pos: { top: rect.top, left: rect.left, right: "auto", bottom: "auto" }
                });
            }
        };

        document.addEventListener("mousemove", onMouseMove);
        document.addEventListener("mouseup", onMouseUp);
    });

    // Action Click
    ppBtn.addEventListener("click", async (e) => {
        if (isDragging) return; // Don't trigger if it was a drag
        if (!lastFocusedInput) {
            alert("Click on an input first!");
            return;
        }

        if (!isContextValid()) return ppBtn.remove();

        let text = "";
        if (lastFocusedInput.tagName === "TEXTAREA" || lastFocusedInput.tagName === "INPUT") {
            text = lastFocusedInput.value;
        } else {
            text = lastFocusedInput.innerText || lastFocusedInput.textContent || "";
        }

        if (!text.trim()) {
            alert("Type something first!");
            return;
        }

        ppBtn.classList.add("enhancing");
        ppBtn.innerHTML = `<span class="pp-spinner"></span> <span>Enhancing...</span>`;

        try {
            const storage = await chrome.storage.local.get(["pp_mode"]);

            chrome.runtime.sendMessage({
                type: "TRANSFORM_PROMPT",
                data: { text, mode: storage.pp_mode || "professional" }
            }, (response) => {
                if (chrome.runtime.lastError || !response || response.error) {
                    throw new Error(response?.error || "Connection Error");
                }

                if (lastFocusedInput.tagName === "TEXTAREA" || lastFocusedInput.tagName === "INPUT") {
                    lastFocusedInput.value = response.transformed;
                } else {
                    lastFocusedInput.innerText = response.transformed;
                }

                lastFocusedInput.dispatchEvent(new Event('input', { bubbles: true }));
                lastFocusedInput.dispatchEvent(new Event('change', { bubbles: true }));

                ppBtn.innerHTML = `✓ Done`;
                ppBtn.classList.remove("enhancing");
                setTimeout(resetBtn, 2000);
            });

        } catch (err) {
            ppBtn.innerHTML = `✗ ${err.message}`;
            ppBtn.classList.remove("enhancing");
            setTimeout(resetBtn, 3000);
        }
    });
}

function resetBtn() {
    if (!ppBtn) return;
    ppBtn.innerHTML = `
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1-1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
    </svg>
    <span>Enhance</span>
  `;
}

// Track focus across the page
document.addEventListener("focusin", (e) => {
    const target = e.target;
    const isAIInput = inputSelectors.some(sel => target.matches(sel)) ||
        target.getAttribute('contenteditable') === 'true';

    if (isAIInput) {
        lastFocusedInput = target;
        if (ppBtn) {
            ppBtn.style.opacity = "1";
            ppBtn.style.pointerEvents = "auto";
        }
    }
});

// Create button on load
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", createFloatingButton);
} else {
    createFloatingButton();
}
