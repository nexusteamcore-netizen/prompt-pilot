// This script runs on the PromptPilot website to sync the auth token and config to the extension
const syncToExtension = () => {
  const currentUrl = window.location.origin;
  chrome.storage.local.set({ pp_base_url: currentUrl }, () => {
    console.log("PromptPilot: Base URL synced:", currentUrl);
  });

  try {
    // Supabase stores auth tokens in localStorage
    const keys = Object.keys(localStorage);
    const sbKey = keys.find(k => k.startsWith('sb-') && k.endsWith('-auth-token'));

    if (sbKey) {
      const authData = JSON.parse(localStorage.getItem(sbKey) || '{}');
      if (authData && authData.access_token) {
        chrome.storage.local.set({ pp_token: authData.access_token }, () => {
          console.log("PromptPilot: Auth token synced.");
        });
      }
    }
  } catch (e) {
    console.error("PromptPilot Sync Error:", e);
  }
};

window.addEventListener("message", (event) => {
  if (event.source !== window) return;

  if (event.data.type && event.data.type === "PP_AUTH_TOKEN") {
    const token = event.data.token;
    if (token) {
      chrome.storage.local.set({ pp_token: token });
    } else {
      chrome.storage.local.remove("pp_token");
    }
    syncToExtension(); // Refresh everything
  }
});

// Initial sync
syncToExtension();
