document.addEventListener("DOMContentLoaded", async () => {
  const modeSelect = document.getElementById("mode");
  const usageDisplay = document.getElementById("usage");
  const dashboardLink = document.getElementById("dashboard-link");

  // Load saved mode
  const { pp_mode } = await chrome.storage.local.get("pp_mode");
  if (pp_mode) modeSelect.value = pp_mode;

  modeSelect.addEventListener("change", (e) => {
    chrome.storage.local.set({ pp_mode: e.target.value });
  });

  // Fetch usage
  const { pp_token } = await chrome.storage.local.get("pp_token");
  if (pp_token) {
    try {
      const { pp_base_url } = await chrome.storage.local.get("pp_base_url");
      const BASE_URL = pp_base_url || "https://ais-pre-lzc3olz63wxecsswu54iou-446069932777.europe-west2.run.app";

      const res = await fetch(`${BASE_URL}/api/usage`, {
        headers: { "Authorization": `Bearer ${pp_token}` }
      });
      if (res.ok) {
        const data = await res.json();
        usageDisplay.innerText = `${data.used} / ${data.total}`;
      }
    } catch (e) {
      console.error(e);
    }
  } else {
    usageDisplay.innerText = "Please sign in";
  }

  dashboardLink.addEventListener("click", async () => {
    const { pp_base_url } = await chrome.storage.local.get("pp_base_url");
    const BASE_URL = pp_base_url || "https://ais-pre-lzc3olz63wxecsswu54iou-446069932777.europe-west2.run.app";
    chrome.tabs.create({ url: `${BASE_URL}/dashboard` });
  });
});
